export { default } from "./SkillImportance";
