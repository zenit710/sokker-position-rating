import React from "react";
import ReactDOM from "react-dom";
import OptionsPage from "@/page/Options";

ReactDOM.render(
    <OptionsPage />,
    document.querySelector(".app"),
);
