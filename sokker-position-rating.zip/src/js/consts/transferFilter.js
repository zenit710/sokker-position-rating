const TYPE_PLAYER = "player";
const TYPE_TRAINER = "trainer";

export { TYPE_PLAYER, TYPE_TRAINER };
