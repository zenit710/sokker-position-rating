export { default } from "./InviteAll";
