export { default } from "./SkillsSumCriteria";
