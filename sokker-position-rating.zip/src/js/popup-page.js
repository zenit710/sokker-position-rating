import React from "react";
import ReactDOM from "react-dom";
import PopupPage from "@/page/Popup";

ReactDOM.render(
    <PopupPage />,
    document.querySelector(".app"),
);
