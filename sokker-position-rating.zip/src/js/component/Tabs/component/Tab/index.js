export { default } from "./Tab";
