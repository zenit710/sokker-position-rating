export { default, TYPE_ERROR, TYPE_SUCCESS, TYPE_INFO } from "./Message";
