export { default } from "./SkillsSum";
